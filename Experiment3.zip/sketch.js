let words;
let index = 0;
let song;

function setup() {
  createCanvas(800, 600);
  background(0);
  textSize(24);
  textAlign(CENTER, CENTER);
  song.loop();
  song.setVolume(8.9);

  let poem = "I can't  promise to love you perfectly but i can promise to love you endlessly";
  words = poem.split(" ");
  
}

function preload() {
  song = loadSound('love.mp3');
}

function draw() {
  background(0, 25); 

  translate(width / 2, height / 2);

  for (let i = 0; i < index; i++) {
    let x = random(-180, 180);
    let y = random(-120, 120);

    fill(255);
    text(words[i], x, y);
  }

 
  if (frameCount % 100 === 0 && index < words.length) {
    index++;
  }
}