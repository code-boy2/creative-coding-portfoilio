let brushType = 1;
let brushColor;
let strokes = [];
let soundLevel = 0;

function setup(){
  createCanvas(600, 600);
  background(10);
  brushColor = color(255);
}

function draw(){
  background(10, 20); 
  for (let s of strokes){
    s.show();
  }
  fill(255);
  noStroke();
  textSize(14);
  text("1=Glow  2=Square  3=Line  4=Spray  |  C=Clear  Z=Undo", 10, 20);
}


function mouseDragged(){
  let strokeObj;
  if (brushType === 1){
    strokeObj = new GlowBrush(mouseX, mouseY);
  }
  else if (brushType === 2){
    strokeObj = new SquareBrush(mouseX, mouseY);
  }
  else if (brushType === 3){
    strokeObj = new LineBrush(mouseX, mouseY, pmouseX, pmouseY);
  }
  else if (brushType === 4){
    strokeObj = new SprayBrush(mouseX, mouseY);
  }
  strokes.push(strokeObj);
}

class GlowBrush{
  constructor(x, y){
    this.x = x;
    this.y = y;
    this.size = 20 + soundLevel * 200;
    this.alpha = 200;
  }

  show(){
    noStroke();
    fill(0, 255, 255, this.alpha);
    ellipse(this.x, this.y, this.size);

    fill(255, 0, 255, this.alpha / 2);
    ellipse(this.x, this.y, this.size * 0.6);
  }
}

class SquareBrush{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }

  show(){
    noStroke();
    fill(255, 120, 150);
    rect(this.x, this.y, 25, 25);
  }
}


class LineBrush{
  constructor(x, y, px, py){
    this.x = x;
    this.y = y;
    this.px = px;
    this.py = py;
  }

  show(){
    stroke(100, 200, 255);
    strokeWeight(3);
    line(this.x, this.y, this.px, this.py);
  }
}


class SprayBrush{
  constructor(x, y){
    this.x = x;
    this.y = y;
  }

  show(){
    noStroke();

    for (let i = 0; i < 10; i++){
      fill(random(255), random(255), random(255));
      ellipse(
        this.x + random(-15, 15),
        this.y + random(-15, 15),
        5
      );
    }
  }
}

function keyPressed(){
  if (key === '1') brushType = 1;
  if (key === '2') brushType = 2;
  if (key === '3') brushType = 3;
  if (key === '4') brushType = 4;
  if (key === 'c'){
    strokes = [];
    background(10);
  }
  
  if (key === 'z'){
    strokes.pop();
  }
}