let sounds = {};
let amp = {};
let currentColor;
let particles = [];

function preload(){
  sounds = {
    a: loadSound('justin1.mp3'),
    s: loadSound('faaah.mp3'),
    w: loadSound('wipe.mp3'),
    d: loadSound('67.mp3'),
    q: loadSound('HAHA.mp3')
  };
}

function setup(){
  createCanvas(500, 500);
  currentColor = color(0);

  
  for (let key in sounds){
    amp[key] = new p5.Amplitude();
    amp[key].setInput(sounds[key]);
    sounds[key].setVolume(1);
  }
}

function draw(){
  drawGradient();

  
  for (let i = particles.length - 1; i >= 0; i--){
    let p = particles[i];
    p.update();
    p.show();

    if (p.alpha <= 0){
      particles.splice(i, 1);
    }
  }

  for (let key in sounds){
    if (sounds[key].isPlaying()){
      let level = amp[key].getLevel();
      let size = map(level, 0, 0.3, 50, 300);

      fill(currentColor);
      noStroke();
      ellipse(width/2, height/2, size);
    }
  }
}


function drawGradient(){
  for (let y = 0; y < height; y++){
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(currentColor, color(0), inter);
    stroke(c);
    line(0, y, width, y);
  }
}


function playSound(s){
  if (s.isPlaying()) s.stop();
  s.play();
}


class Particle{
  constructor(x, y, col){
    this.x = x;
    this.y = y;
    this.size = random(5, 15);
    this.alpha = 255;
    this.col = col;
    this.vx = random(-2, 2);
    this.vy = random(-2, 2);
  }
  

  update(){
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 4;
  }

  show(){
    noStroke();
    fill(red(this.col), green(this.col), blue(this.col), this.alpha);
    ellipse(this.x, this.y, this.size);
  }
}


function keyTyped(){
  let col;

  if (key === 'e'){
    playSound(sounds.a);
    col = color(255, 80, 80);
  }
  else if (key === 't'){
    playSound(sounds.s);
    col = color(80, 255, 120);
  }
  else if (key === 'h'){
    playSound(sounds.w);
    col = color(80, 150, 255);
  }
  else if (key === 'a'){
    playSound(sounds.d);
    col = color(255, 200, 80);
  }
  else if (key === 'n'){
    playSound(sounds.q);
    col = color(200, 80, 255);
  }

  if (col){
    currentColor = col;

    for (let i = 0; i < 30; i++){
      particles.push(new Particle(width/2, height/2, col));
    }
  }
}